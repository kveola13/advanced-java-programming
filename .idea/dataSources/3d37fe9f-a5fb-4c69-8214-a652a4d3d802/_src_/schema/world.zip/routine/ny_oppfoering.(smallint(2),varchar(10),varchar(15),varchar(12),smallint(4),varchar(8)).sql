CREATE PROCEDURE ny_oppfoering(IN  nr      SMALLINT(2), IN fornavn VARCHAR(10), IN etternavn VARCHAR(15),
                               IN  adresse VARCHAR(12), IN postnummer SMALLINT(4), IN telefon VARCHAR(8),
                               OUT melding VARCHAR(12))
  BEGIN INSERT INTO telefonliste VALUES
    (nr, fornavn, etternavn, adresse, postnummer, telefon);
    COMMIT;
    SET melding = 'Vellykket';
  END;
